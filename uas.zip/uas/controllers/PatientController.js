// TODO 4: SETUP CONTROLLER

// import model Patient
const Patient = require("../models/Patient.JS");

// Buat Class PatientController
class PatientController {
  async index(req, res) {
    // memanggil method static all dengan async await
    const patients = await Patient.findAll();

    // menampilkan data patients
    if (patients) {
      const data = {
        message: "Menampilkan Semua Patient",
        data: patients,
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data not found",
      };
      res.status(404).json(data);
    }
  }

  async store(req, res) {
    // destructing object req.body
    const { name, phone, address, status, in_date_at, out_date_at, timestamp } =
      req.body;

    // memanggil method create dengan async await
    const patients = await Patient.create(req.body);

    // menambahkan data patients dengan validasi
    if (!address || !status || !in_date_at) {
      const data = {
        message: "Data tidak valid",
      };
      return res.status(422).json(data);
    } else {
      const data = {
        message: "Menambahkan Data Patient",
        data: patients,
      };
      res.status(201).json(data);
    }
  }

  async update(req, res) {
    // memanggil method update
    await Patient.update(req.body, {
      where: {
        id: req.params.id,
      },
    });

    const patientUpdate = await Patient.findAll({
      where: {
        id: req.params.id,
      },
    });
    // mengupdate data patient
    if (patientUpdate.length > 0) {
      const data = {
        message: "Mengupdate Semua Patient",
        data: patientUpdate,
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data not found",
      };
      res.status(404).json(data);
    }
  }

  async destroy(req, res) {
    // memanggil method find untuk mencari id menggunakan async await
    const patient = await Patient.destroy({
      where: {
        id: req.params.id,
      },
    });

    // menghapus data patient
    if (patient) {
      const data = {
        message: "Mengapus Data Patient",
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data Not Found",
      };
      res.status(404).json(data);
    }
  }

  async show(req, res) {
    // memanggil method find untuk mencari id menggunakan async await
    const patient = await Patient.findOne({
      where: {
        id: req.params.id,
      },
    });

    // Menampilkan Detail Patient
    if (patient) {
      const data = {
        message: "Menampilkan Detail Patient",
        data: patient,
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data Not Found",
      };
      res.status(404).json(data);
    }
  }

  async search(req, res) {
    // destructing object req.body
    const { name } = req.params;
    // memanggil method find untuk mencari nama
    const patient = await Patient.findAll({
      where: {
        name: name,
      },
    });

    // if (patient.isEmpty()) {
    //   const data = {
    //     message: "Menampilkan Data Patient yang dicari",
    //     data: patient,
    //   };
    //   res.status(200).json(data);
    // } else {
    //   const data = {
    //     message: "Data Not Found",
    //   };
    //   res.status(404).json(data);
    // }

    if (patient.length > 0) {
      const data = {
        message: "Menampilkan Data Patient yang dicari",
        data: patient,
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data Not Found",
      };
      res.status(404).json(data);
    }
  }

  async positive(req, res) {
    // memanggil method find untuk mencari nama
    const patient = await Patient.findAll({
      where: {
        status: "positive",
      },
    });

    if (patient) {
      const data = {
        message: "Menampilkan Data Patient yang positive",
        data: patient,
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data Not Found",
      };
      res.status(404).json(data);
    }
  }

  async recovered(req, res) {
    // memanggil method find untuk mencari nama
    const patient = await Patient.findAll({
      where: {
        status: "recovered",
      },
    });

    if (patient) {
      const data = {
        message: "Menampilkan Data Patient yang sembuh",
        data: patient,
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data Not Found",
      };
      res.status(404).json(data);
    }
  }

  async dead(req, res) {
    // memanggil method find untuk mencari nama
    const patient = await Patient.findAll({
      where: {
        status: "dead",
      },
    });

    if (patient) {
      const data = {
        message: "Menampilkan Data Patient yang telah meninggal",
        data: patient,
      };
      res.status(200).json(data);
    } else {
      const data = {
        message: "Data Not Found",
      };
      res.status(404).json(data);
    }
  }
}

// membuat object PatientController
const object = new PatientController();

// export object PatientController
module.exports = object;
