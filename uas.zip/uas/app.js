/**
 * TODO 1: SETUP SERVER USING EXPRESS.JS.
 * UBAH SERVER DI BAWAH MENGGUNAKAN EXPRESS.JS.
 * SERVER INI DIBUAT MENGGUNAKAN NODE.JS NATIVE.
 */

// import express
const express = require("express");

// import express-validator
const expressValidator = require("express-validator");

// import express-session
const expressSession = require("express-session");

// const { body, validationResult } = require("express-validator");

// app.post(
//   "/user",
// username harus merupakan email
//   body("username").isEmail(),
// panjang password minimal 5 karakter
//   body("password").isLength({ min: 5 }),
//   (req, res) => {
// mencari error validasi pada request
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       return res.status(400).json({ errors: errors.array() });
//     }

//     User.create({
//       username: req.body.username,
//       password: req.body.password,
//     }).then((user) => res.json(user));
//   }
// );

// buat object/server
const app = express();

// definisikan port
app.listen(3000, () => {
  console.log("Server berjalan di: http://localhost:3000");
});

// pake router
const router = require("./routes/api");
app.use(express.json());
app.use(express.urlencoded());
app.use(router);
app.use(express.expressValidator);
app.use(
  expressSession({ secret: "wangsit", saveUninitialized: false, resave: false })
);
