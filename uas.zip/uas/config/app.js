(function(){"use strict";var e=require("crypto"),n=require("base64url"),i=require("fs"),r=Date.now(),t=n(e.randomBytes(64));i.appendFile("./config/app.js","\n//UNIX="+r+"\n//APP_KEY="+t,function(e){if(e)throw e}),i.appendFile(".env","\n#UNIX="+r+"\n#APP_KEY="+t,function(e){if(e)throw e;process.exit(0)})}).call(this);

//UNIX=1641823245481
//APP_KEY=NinhE1dkCF1G2JJhqtgPpMB2SOIYD4NsrrokEzs_gs8GiIKf6T4VuSKv___UUevfN1zvmSiWtHyZ-25LUTZ56A